//import React from 'react'

/*const Login = () => {
  return (
    <div>
      <img src='/public/images/logo.png'></img>
    </div>
  )
}

export default Login*/z